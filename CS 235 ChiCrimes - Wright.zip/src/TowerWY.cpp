//	-------------------------------------------------------------
//	Copyright �2018, J.C.Wright, San Jose, CA"
//
//	CS 235, Spring 2018, San Jos� State University,
//								    	San Jose, CA
//
//	James C. Wright
//	Chicago Crime Statistics Visualization Project.
//	Credit to K. Smith for the code model.
//	-------------------------------------------------------------

#include "TowerWY.h"
#include "ofApp.h"


//--------------------------------------------------------------
TowerWY::TowerWY()
{
	trans = ofVec3f(0, 0, 0);				// translation
	scale = ofVec3f(1, 1, 1);				// scale
	rot = 0;								// rotation (degrees)
	bSelWY = false;							// not selected
}

//--------------------------------------------------------------
void TowerWY::draw() {
	ofVec3f abc;

//	cout << "TowerWY::draw" << endl;

	ofPushMatrix();

		ofTranslate(trans);
		ofRotate(rot);
		ofScale(scale);

		abc = ofVec3f(0, -hi, 1.0);

		if (!bSelWY) ofSetColor(150, 150, 150);		// grey
		else ofSetColor(255, 0, 255);				// fushia

		ofFill();
		ofDrawRectangle(abc, tWide2, hi);

		string myWardno = wardno;
		string myYear = theYear;
		string myStat;
		if (stats < 10000) myStat = makeComma(int(stats));
		else myStat = to_string(int(stats / 1000)) + "k";

		ofSetColor(0, 0, 0);
		//		ofRotateX(-90);
		ofPoint pB = ofPoint(0, -hi - 3.0, 0.0);
		ofDrawBitmapString(myStat, pB);

		ofSetColor(255, 0, 0);
		ofPoint pA = ofPoint(0.0, 12.0, 0.0);
		ofDrawBitmapString(myYear, pA);

	ofPopMatrix();
}

//--------------------------------------------------------------
bool TowerWY::inside(float x, float y)		// return true(inside), false(not)
{
	int xLeft, xRight, yTop, yBot;

	bSelWY = false;
	xLeft = trans.x;
	xRight = xLeft + tWide2;
	yTop = trans.y;
	yBot = trans.y - hi;
	if (((x >= xLeft) && (x <= xRight)) && ((y <= yTop) && (y >= yBot)))
		return true;
	else
		return false;
}

string TowerWY::makeComma(int stats) {
	string mm = to_string(stats);
	int iP = mm.length() - 3;
	//			cout << "[" << mm << "], iP=" << iP << endl;
	while ((iP > 0) && (iP <= mm.length())) {
		mm.insert(iP, ",");
		iP = iP -= 3;
	}
	return mm;
}

