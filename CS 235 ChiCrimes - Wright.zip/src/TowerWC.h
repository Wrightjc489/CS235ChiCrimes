//	-------------------------------------------------------------
//	Copyright �2018, J.C.Wright, San Jose, CA"
//
//	CS 235, Spring 2018, San Jos� State University,
//								    	San Jose, CA
//
//	James C. Wright
//	Chicago Crime Statistics Visualization Project.
//	Credit to K. Smith for the code model.
//	-------------------------------------------------------------

#pragma once

#include "ofMain.h"


// Data Structure: by Primary Crime (one ward)
class BaseObj4 {
public:
	ofVec3f trans, scale;				// Translate & Scale
	float rot;							// rotation (degrees)
	float x, y, z, hi;					// x, y, z, high
	string wardno;						// Ward Number
	int code;							// Tower number
	string theCrime;					// Primary Crime
	long stats;							// statistic
	bool bSelWC;						// selected-true, or not-false
};

class TowerWC : public BaseObj4 {
public:
	TowerWC();							// Tower Rectangle
	void draw();
	bool inside(float x, float y);		// return true(inside), false(not)
	string makeComma(int stats);

	ofRectangle towerWC;				// the figure
	bool built;							// is it built?

	const int tWide = 15;				// Tower width

};

