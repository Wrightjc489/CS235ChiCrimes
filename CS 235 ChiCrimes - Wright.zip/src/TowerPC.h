//	-------------------------------------------------------------
//	Copyright �2018, J.C.Wright, San Jose, CA"
//
//	CS 235, Spring 2018, San Jos� State University,
//								    	San Jose, CA
//
//	James C. Wright
//	Chicago Crime Statistics Visualization Project.
//	Credit to K. Smith for the code model.
//	-------------------------------------------------------------

#pragma once

#include "ofMain.h"


// Data Structure: by Primary Crime (all city)
class BaseObj5 {
public:
	ofVec3f trans, scale;				// Translate & Scale
	float rot;							// rotation (degrees)
	float x, y, z, hi;					// x, y, z, high
	int code;							// Tower number
	string theCrime;					// crime
	long stats;							// statistic
	bool bSelPC;						// selected-true, or not-false
};

class TowerPriCrime : public BaseObj5 {
public:
	TowerPriCrime();					// Tower Rectangle
	void draw();
	bool inside(float x, float y);		// return true(inside), false(not)

	ofRectangle towerpricrime;			// the figure
	bool built;							// is it built?

	string makeComma(int stats);
	
	const int tWide2 = 15;				// Tower width

};
