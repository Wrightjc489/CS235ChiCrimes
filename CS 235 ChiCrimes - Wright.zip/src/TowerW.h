//	-------------------------------------------------------------
//	Copyright �2018, J.C.Wright, San Jose, CA"
//
//	CS 235, Spring 2018, San Jos� State University,
//								    	San Jose, CA
//
//	James C. Wright
//	Chicago Crime Statistics Visualization Project.
//	Credit to K. Smith for the code model.
//	-------------------------------------------------------------

#pragma once

#include "ofMain.h"


// Data Structure: by Ward
class BaseObj1 {
public:
	ofVec3f trans, scale;			// Translate & Scale
	float rot;						// rotation (degrees)
	float x, y, z, hi;				// x, y, z, high
	string wardno;					// Ward Number
	string AldNm;					// Alderman Name
	long stats;						// statistic
	bool bSelW;						// selected-true, or not-false
};

class TowerWard : public BaseObj1 {
public:
	TowerWard();						// Tower Rectangle
	void draw();
	bool inside(float x, float y);		// return true(inside), false(not)
	bool insid2(float x, float y);
	bool insid3(float x, float y);

	void drawmap(string tWard,
				 string fName);			// draw map

	string sWard;
	bool built;							// is it built?

	ofImage chiMap;						// selected Chicago map image
	bool chiMapLoad = false;

	const int tWide = 15;				// wide tower width
	const int tNarrow = 5;				// narrow tower width

};

