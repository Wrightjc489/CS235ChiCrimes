//	-------------------------------------------------------------
//	Copyright �2018, J.C.Wright, San Jose, CA"
//
//	CS 235, Spring 2018, San Jos� State University,
//								    	San Jose, CA
//
//	James C. Wright
//	Chicago Crime Statistics Visualization Project.
//	Credit to K. Smith for the code model.
//	-------------------------------------------------------------

#pragma once

#include "ofMain.h"
#include "TowerW.h"
#include "TowerY.h"
#include "TowerPC.h"
#include "TowerWY.h"
#include "TowerWC.h"

// class manip;									// later, maybe


class ofApp : public ofBaseApp{

public:
	void setup();
	void update();
	void draw();

	void renderSelection();
	void processSelection(int x, int y);

	void keyPressed(int key);
	void keyReleased(int key);
	void mouseMoved(int x, int y );
	void mouseDragged(int x, int y, int button);
	void mousePressed(int x, int y, int button);
	void mouseReleased(int x, int y, int button);
	void mouseEntered(int x, int y);
	void mouseExited(int x, int y);
	void windowResized(int w, int h);
	void dragEvent(ofDragInfo dragInfo);
	void gotMessage(ofMessage msg);

	long getWardDataMax(string fName);
	bool getWardData(string fName);
	void setWardBlock(int k);

	long getYearDataMax(string fName);			// returns maximum statistic
	bool getYearData(string fName);				// builds vector
	void setYearBlock(int k);					// produces information block

	long getPriCrimeDataMax(string fName);		// returns maximum statistic
	bool getPriCrimeData(string fName);			// builds vector
	void setPriCrimeBlock(int k);				// produces information block

	long getWYDataMax(string fName);
	bool getWYData(string fName);
	void setWYBlock(int k);

	long getWCDataMax(string fName);
	bool getWCData(string fName);
	void setWCBlock(int k);

	string makeComma(int stats);

	//Manip *manip;
		
//	extern bool mapActive = false;
	bool mapActive = false;			// map is activated
	bool Yactive = false;			// by Year is activated
	bool PCactive = false;			// by Primary Crime is activated
	bool WYactive = false;			// Ward by Year is activated
	bool WCactive = false;			// Ward by Crime is activated

	int WinW, WinH;					// Window dimensions (W-wide, H-High

	int tMaxSiz;					// Tower real maximum size in window
	int shiftX;						// Space between towers + width

	const int tWide = 15;			// Tower width
	const int tWide2 = 30;


private:
	bool ctrlKeyDown;				// Switchs for keys
	bool shiftKeyDown;
	bool altKeyDown;

	int SelectedTower = 0;			// ID of selected item

	ofImage ChiSeal;				// background image
	bool bChiSeal = true;			// records if loaded-true, or not-false

	ofVec3f mouse_last;				// Last Mouse position

	string iName, fName;			// holds an image, file name
	string tLine;					// line of file input

	TowerWard myWardTower;			// define object

	double sWardMax;				// largest ward value
	string lineWardNumber;			// ward number
	double lineWardValue;			// Ward crime count
	vector<TowerWard> wardList;		// List containing all WARD towers
	ofRectangle wardInfoRect;		// Ward information block
	bool bwardInfo = false;

	TowerYear myYearTower;			// define object

	double sYearMax;				// largest year value
	string lineYearNumber;			// Year number
	double lineYearValue;			// Year crime count
	vector<TowerYear> yearList;		// List containing all YEAR towers
	ofRectangle yearInfoRect;		// Year information block
	bool byearInfo = false;

	TowerPriCrime myPriCrimeTower;	// define object

	double sPriCrimeMax;			// largest year value
	string linePriCrime;			// Year number
	double linePriCrimeValue;		// Year crime count
	vector<TowerPriCrime> pricrimeList;	// List containing all YEAR towers
	ofRectangle pricrimeInfoRect;	// Year information block
	bool bPriCrimeInfo = false;

	TowerWY myWYTower;				// define object

	double sWYMax;					// largest year value
	string lineWYNumber;			// ward number
	string lineWYYear;				// Year number
	double lineWYValue;				// Year crime count
	vector<TowerWY> WYList1;		// List of only one Ward/Year.
	vector<TowerWY> WYList2;		// List containing all ward-year towers
	ofRectangle WYInfoRect;			// Year information block
	bool bWYInfo = false;

	TowerWC myWCTower;				// define object

	double sWCMax;					// largest Crime value
	string lineWCNumber;			// ward number
	string lineWCCrime;				// Primary Crime
	double lineWCValue;				// Year crime count
	vector<TowerWC> WCList1;		// List of only one Ward/Crime.
	vector<TowerWC> WCList2;		// List containing all ward-Crime towers
	ofRectangle WCInfoRect;			// Year information block
	bool bWCInfo = false;

	ofPoint dragPt;					// drag point

	ofRectangle mapButton;			// map button
	ofPoint ptMapButton = ofPoint(350, 5);
	bool bMapButton = false;

	ofRectangle byYearButton;
//	ofPoint ptYearButton;
	int osYearButton = 90;			// offset
	bool bYearButton = false;

	ofRectangle byPriCrimeButton;
//	ofPoint ptPriCrimeButton;
	int osPriCrimeButton = 100;		// offset
	bool bPriCrimeButton = false;

//	ofImage chiMap;					// selected Chicago map image
//	bool chiMapLoad = false;
};
