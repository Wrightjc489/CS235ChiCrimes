//	-------------------------------------------------------------
//	Copyright �2018, J.C.Wright, San Jose, CA"
//
//	CS 235, Spring 2018, San Jos� State University,
//								    	San Jose, CA
//
//	James C. Wright
//	Chicago Crime Statistics Visualization Project.
//	Credit to K. Smith for the code model.
//	-------------------------------------------------------------

#include "TowerWC.h"
#include "ofApp.h"


//--------------------------------------------------------------
TowerWC::TowerWC()
{
	trans = ofVec3f(0, 0, 0);				// translation
	scale = ofVec3f(1, 1, 1);				// scale
	rot = 0;								// rotation (degrees)
	bSelWC = false;							// not selected
}

//--------------------------------------------------------------
void TowerWC::draw() {
	ofVec3f abc;

//	cout << "TowerWC::draw" << endl;

	ofPushMatrix();

//		if (theYear == "0") return;

		ofTranslate(trans);
		ofRotate(rot);
		ofScale(scale);

		abc = ofVec3f(0, -hi, 1.0);

		if (!bSelWC) ofSetColor(150, 150, 150);		// grey
		else ofSetColor(255, 0, 255);				// fushia

		ofFill();
		ofDrawRectangle(abc, tWide, hi);

		string myStat;
		if (stats < 10000) myStat = makeComma(int(stats));
		else myStat = to_string(int(stats / 1000)) + "k";

		ofSetColor(0, 0, 0);
		//		ofRotateX(-90);
		ofPoint pB = ofPoint(0, -hi - 3.0, 0.0);
		ofDrawBitmapString(myStat, pB);

		ofSetColor(255, 0, 0);
		ofPoint pA = ofPoint(0.0, 12.0, 0.0);
		ofDrawBitmapString(code, pA);

	ofPopMatrix();
}

//--------------------------------------------------------------
bool TowerWC::inside(float x, float y)		// return true(inside), false(not)
{
	int xLeft, xRight, yTop, yBot;

	bSelWC = false;
	xLeft = trans.x;
	xRight = xLeft + tWide;
	yTop = trans.y;
	yBot = trans.y - hi - 15;
	if (((x >= xLeft) && (x <= xRight)) && ((y <= yTop) && (y >= yBot)))
		return true;
	else
		return false;
}

//--------------------------------------------------------------
string TowerWC::makeComma(int stats) {
	string mm = to_string(stats);
	int iP = mm.length() - 3;
	//			cout << "[" << mm << "], iP=" << iP << endl;
	while ((iP > 0) && (iP <= mm.length())) {
		mm.insert(iP, ",");
		iP = iP -= 3;
	}
	return mm;
}

