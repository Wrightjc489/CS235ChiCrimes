//	-------------------------------------------------------------
//	Copyright �2018, J.C.Wright, San Jose, CA"
//
//	CS 235, Spring 2018, San Jos� State University,
//								    	San Jose, CA
//
//	James C. Wright
//	Chicago Crime Statistics Visualization Project.
//	Credit to K. Smith for the code model.
//	-------------------------------------------------------------

#include "TowerW.h"
#include "ofApp.h"



//--------------------------------------------------------------
TowerWard::TowerWard()
{
	trans = ofVec3f(0, 0, 0);				// translation
	scale = ofVec3f(1, 1, 1);				// scale
	rot = 0;								// rotation (degrees)
	bSelW = false;							// not selected
}

//--------------------------------------------------------------
void TowerWard::draw() {
	ofVec3f abc, def, ghi;

	ofPushMatrix();

		ofTranslate(trans);
		ofRotate(rot);
		ofScale(scale);

		abc = ofVec3f(0, -hi, 1.0);
		def = ofVec3f(tWide, -hi, 1.0);
		ghi = ofVec3f(tWide, -hi/2, 1.0);

		// draw main tower
		if (!bSelW) {
			ofSetColor(150, 150, 150);				// grey
//			cout << "Grey" << endl;
		}
		else {
			ofSetColor(255, 0, 255);				// fushia
//			cout << "fushia" << endl;
		}

		// draw main tower
		ofFill();
		ofDrawRectangle(abc, tWide, hi);
		
		// draw side tower 1
		ofFill();
		if (!bSelW) ofSetColor(150, 150, 150);		// grey
		else ofSetColor(100, 149, 237);				// cornflower blue
		ofDrawRectangle(def, tNarrow, hi/2);

		// draw side tower 2
		ofFill();
		if (!bSelW) ofSetColor(150, 150, 150);		// grey
		else ofSetColor(154, 205, 50);				// yellowgreen
		ofDrawRectangle(ghi, tNarrow, hi/2);

		string myWard = wardno;
		string myStat = to_string(int(stats / 1000)) + "k";

//		ofRotateX(-90);
		ofPoint pB = ofPoint(0, -hi - 4.0, 0.0);	// Statistic above tower
		ofSetColor(0, 0, 255);						// blue
		ofDrawBitmapString(myStat,pB);

		ofPoint pA = ofPoint(0, 12.0, 0.0);			// Ward # below tower
		ofSetColor(255, 0, 0);						// red
		ofDrawBitmapString(myWard, pA);

	ofPopMatrix();
}

//--------------------------------------------------------------
bool TowerWard::inside(float x, float y)			// return true(inside), false(not)
{
	int xLeft, xRight, yTop, yBot;

//	cout << "inside x=" << x << ", y=" << y << endl;
//	bSelW = false;
	xLeft = trans.x;
	xRight = xLeft + tWide;
	yTop = trans.y;
	yBot = trans.y - hi;
	if (((x >= xLeft) && (x <= xRight)) && ((y <= yTop) && (y >= yBot))) 
		return true;
	else
		return false;
}

//--------------------------------------------------------------
bool TowerWard::insid2(float x, float y)			// return true(inside), false(not)
{
	int xLeft, xRight, yTop, yBot;

//	cout << "insid2 x=" << x << ", y=" << y << endl;
//	bSelW = false;
	xLeft = trans.x + tWide;
	xRight = xLeft + tNarrow;	
	yTop = trans.y;
	yBot = trans.y - (hi / 2);
	if (((x >= xLeft) && (x <= xRight)) && ((y <= yTop) && (y >= yBot)))
		return true;
	else
		return false;
}

//--------------------------------------------------------------
bool TowerWard::insid3(float x, float y)
{
	int xLeft, xRight, yTop, yBot;

//	cout << "insid3 x=" << x << ", y=" << y << endl;
//	bSelW = false;
	xLeft = trans.x + tWide;
	xRight = xLeft + tNarrow;	
	yTop = trans.y - (hi / 2);
	yBot = trans.y - hi;
	if (((x >= xLeft) && (x <= xRight)) && ((y <= yTop) && (y >= yBot)))
		return true;
	else
		return false;
}

//--------------------------------------------------------------
void TowerWard::drawmap(string tWard, string fName)
{
	ofPushMatrix();

	if (sWard != tWard) {
		if (chiMap.load(fName) == false) {
			cout << "Can\'t load image: " << fName << endl;
			chiMapLoad = false;
			return;
		}
		else {
			sWard = tWard;
			cout << "Map loaded [" << sWard << "]." << endl;
			chiMapLoad = true;
		}
	}

	float rat;
	int mWW = chiMap.getWidth();
	int mHH = chiMap.getHeight();
	long WinW2 = (ofGetWindowWidth() - 100);
	long WinH2 = (ofGetWindowHeight() - 100);
	if (WinW2 > WinH2) rat = WinH2 / mWW;
	else rat = WinW2 / mHH;
	float sWW = mWW * rat;
	float sHH = mHH * rat;
	chiMap.resize(sWW, sHH);

	ofSetColor(255, 255, 255);
	ofFill();
	chiMap.draw(ofPoint(100, 100), sWW, sHH);

	ofPopMatrix();
}

