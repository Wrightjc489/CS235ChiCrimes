//	-------------------------------------------------------------
//	Copyright �2018, J.C.Wright, San Jose, CA"
//
//	CS 235, Spring 2018, San Jos� State University,
//								    	San Jose, CA
//
//	James C. Wright
//	Chicago Crime Statistics Visualization Project.
//	Credit to K. Smith for the code model.
//	-------------------------------------------------------------

#include "ofApp.h"

#include <direct.h>
#define GetCurrentDir getcwd

const string copyr = "Copyright �2018, J.C.Wright, San Jose, CA";
const string title0a = "Chicago Crime Statistics by ";
const string title0b = " 2001 - 2018";
const string title1 = "CS 235, Spring 2018, SJSU, James C. Wright";
const string title2 = title0a + "Ward" + title0b;
const string title3 = title0a + "Year" + title0b;
const string title4 = title0a + "Ward-Year" + title0b;
const string title5 = title0a + "Ward-Crime" + title0b;
const string title6 = title0a + "Primary Crime" + title0b;
//	const string baseLoc = "E:/JCW/SJSU Education/CS 235 User Interface Design/Web Project/Chicago/Data/";
const string baseLoc = "";

const string Cdelim = ",";
const int tBaseOffset = 35;
const long tBaseYear = 2001;


//--------------------------------------------------------------
void ofApp::setup() {
	ofSetVerticalSync(true);
	// ofEnableDepthTest();
	ofEnableAlphaBlending();

	ctrlKeyDown = false;						// start with keys normal
	shiftKeyDown = false;
	altKeyDown = false;
	SelectedTower = -1;							// nothing selected

	ofSetWindowTitle(title1);
	ofSetBackgroundAuto(false);

	WinW = ofGetWindowWidth();					// Window dimensions
	WinH = ofGetWindowHeight();
	//	cout << "WinW=" << WinW << ", WinH=" << WinH << endl;

	iName = "Seal_of_Chicago.png";				// Name of image
	if (ChiSeal.load(iName) == false) {
		cout << "Can't load image of Chicago Seal. [" << iName << "]" << endl;
		bChiSeal = false;
	}
	else
		ChiSeal.resize(WinH / 6, WinH / 6);		// Square and 1/6 of window height

	mapActive = false;

	tMaxSiz = WinH - 40;						// Tower real maximum size in window
	
	char cCurrentPath[FILENAME_MAX];
	string baseLoc0 = GetCurrentDir(cCurrentPath,sizeof(cCurrentPath));
	string baseLoc = baseLoc0 + "\\bin\\data\\";

	shiftX = 9 + tWide;							// tower width + space between
	string fName0 = baseLoc + "Wards.txt";
	cout << "fName0=" << fName0 << endl;
	sWardMax = getWardDataMax(fName0);
	if (!getWardData(fName0)) {					// setup the by Year data
		cout << "Ward Data ERROR." << endl;
		return;
	}

	shiftX = 9 + tWide2;						// tower width + space between
	string fName1 = baseLoc + "Years.txt";
	cout << "fName1=" << fName1 << endl;
	sYearMax = getYearDataMax(fName1);
	if (!getYearData(fName1)) {					// setup the by Year data
		cout << "Year Data ERROR." << endl;
		return;
	}

	shiftX = 9 + tWide;							// tower width + space between
	string fName2 = baseLoc + "PriCrimes.txt";
	cout << "fName2=" << fName2 << endl;
	sPriCrimeMax = getPriCrimeDataMax(fName2);
	if (!getPriCrimeData(fName2)) {				// setup the by Primary Crime data
		cout << "Primary Crime Data ERROR." << endl;
		return;
	}

	shiftX = 9 + tWide2;						// tower width + space between
	string fName3 = baseLoc + "WardYears.txt";
	cout << "fName3=" << fName3 << endl;
	sWYMax = getWYDataMax(fName3);
	if (!getWYData(fName3)) {					// setup the ward by Year data
		cout << "Ward-Year Data ERROR." << endl;
		return;
	}

	shiftX = 9 + tWide;							// tower width + space between
	string fName4 = baseLoc + "WardCrimes.txt";
	cout << "fName4=" << fName4 << endl;
	sWCMax = getWCDataMax(fName4);
	if (!getWCData(fName4)) {					// setup the crime by ward data
		cout << "Ward-Crime Data ERROR." << endl;
		return;
	}

	SelectedTower = -1;							// nothing selected
//	wardList[0].bSelW = false;

	ofPoint ptYearButton = ofPoint(WinW - (ChiSeal.getWidth() + osYearButton), 23);
	byYearButton.set(ptYearButton, 60, 15);
	bYearButton = true;

	ofPoint ptPriCrimeButton = ofPoint(WinW - (ChiSeal.getWidth() + osPriCrimeButton), 43);
	byPriCrimeButton.set(ptPriCrimeButton, 70, 15);
	bPriCrimeButton = true;

	mapButton.set(ptMapButton, 45, 15);
	bMapButton = false;

	Yactive = false;
	PCactive = false;
	WCactive = false;
	WYactive = false;

} // setup ...

//--------------------------------------------------------------
void ofApp::update(){

}

//--------------------------------------------------------------
void ofApp::draw() {
	int stat, sep;							// statistic, tic maximum
	string ytic;							// tic value

	int ChiSealX, ChiSealY;
	string tWard;
	ofRectangle mapButton(ptMapButton, 30, 15);						// map Button

	ofBackground(255);						// white
	ofFill();								// solid

	ofSetColor(0, 0, 0);						// black
	ofDrawBitmapString(copyr, WinW - 350, WinH - 6);

	int mySW = 0;					// Ward active (default)
	if (Yactive) mySW = 1;			// Year active
	if (PCactive) mySW = 2;			// Primary Crime active
	if (WCactive) mySW = 3;			// Ward-Crime active
	if (WYactive) mySW = 4;			// Ward-Year active

	double divzr, ticMax;				// quotient, divisor

	if (!PCactive && !WCactive) {
		switch (mySW) {
		case 0:							// Ward
			divzr = 20000;
			ticMax = sWardMax;
			break;
		case 1:							// by Year
			divzr = 50000;
			ticMax = 1.05 * sYearMax;
			break;
		case 4:							// Ward-Year
			divzr = 2000;
			ticMax = sWYMax;
			break;
		default:
			break;
		} // switch ...

		// set the tic marks.
		int quotnt = 1 + (ticMax / divzr);
		for (int n = 0; n < quotnt; n++) {
			sep = (divzr / ticMax) * tMaxSiz;
			stat = -(sep - 36) + (((quotnt - n) * divzr) / ticMax) * tMaxSiz;
			ofSetColor(255, 255, 0);			// yellow
			ofDrawRectangle(ofPoint(0, (WinH)-stat), WinW, 2);

			ytic = " " + to_string(int(((quotnt - n) * divzr) - divzr) / 1000) + "k";
			ofSetColor(0, 0, 0);				// black
			ofDrawBitmapString(ytic, ofPoint(0, WinH - stat - 3));
		}
//		cout << "sep=" << sep << ", stat=" << stat << endl;
	} // if ...
	else {
		switch (mySW) {
		case 2:							// by Primary Crime
			divzr = 10000;	//****************************Log10******
			ticMax = sPriCrimeMax;
			break;
		case 3:							// Ward-Crime
			divzr = 2500;	//****************************Log10******
			ticMax = sWCMax;
			break;
		default:
			break;
		} // switch ...
		cout << "divzr=" << divzr << ", ticMax=" << ticMax << endl;

		// set the tic marks on a logarithmic scale.
		float logMax = 0;
		int quotnt = 1 + (ticMax / divzr);
		for (int n = 1; n < quotnt; n++) {		// Avoid zero - causes an error.
			if (logMax < log10f(n * divzr)) logMax = log10f(n * divzr);
		} // for (#1) ...
		logMax = roundf(logMax);
		
		for (int n = 0; n < logMax; n++) {
			stat = 36 + (n / logMax) * tMaxSiz;
			ofSetColor(255, 255, 0);			// yellow
			ofDrawRectangle(ofPoint(0, (WinH)-stat), WinW, 2);

			ytic = " " + to_string(int(pow(10, n)));
			ofSetColor(0, 0, 0);				// black
			ofDrawBitmapString(ytic, ofPoint(0, WinH - stat - 3));
//			cout << "tMaxSiz=" << tMaxSiz << ", n=" << n <<
//				", pow(10,n)=" << pow(10, n) << ", n/logMax=" << (n / logMax) <<
//				", stat=" << stat << endl;
		} // for (#2) ...

		string ls = "Logarithmic Scale";
		ofDrawBitmapString(ls, ofPoint(100, 100));
		ofDrawBitmapString(ls, ofPoint(100, 300));
		ofDrawBitmapString(ls, ofPoint(300, 200));
		ofDrawBitmapString(ls, ofPoint(300, 400));
		ofDrawBitmapString(ls, ofPoint(500, 100));
		ofDrawBitmapString(ls, ofPoint(500, 300));
		ofDrawBitmapString(ls, ofPoint(700, 200));
		ofDrawBitmapString(ls, ofPoint(700, 400));
		ofDrawBitmapString(ls, ofPoint(900, 300));
	} // else ...

	// place the seal.
	ofSetColor(255, 255, 255);				// white
	ChiSealX = WinW - 20;
	if (bChiSeal) {
		ChiSealX = (WinW - ChiSeal.getWidth()) - 10;	// new x
		ChiSealY = 10;						// new y
		ChiSeal.draw(ChiSealX, ChiSealY);	// upper right corner
	}
	
	ofSetColor(0, 0, 255);					// blue
	ofPoint ptYearButton = ofPoint(WinW - (ChiSeal.getWidth() + osYearButton), 23);
	ofPoint ptPriCrimeButton = ofPoint(WinW - (ChiSeal.getWidth() + osPriCrimeButton), 43);

	switch(mySW) {
	case 0:							// Ward
		ofSetColor(0, 0, 0);					// black
		ofDrawBitmapString(title2, ChiSealX - 350, 10);
		for (int kW = 1; kW < wardList.size(); kW++) {		//skip ward zero.
			if (wardList[kW].bSelW) {
//				cout << "ward=" << wardList[kW].wardno << " selected." << endl;
				wardList[kW].draw();
				SelectedTower = kW;
//				cout << "zero";
				setWardBlock(kW);
			}

			ofSetColor(200, 200, 200);
			ofFill();
			ofDrawRectangle(mapButton);
			ofSetColor(0, 0, 0);
			ofDrawBitmapString("Map", mapButton.getLeft() + 3, mapButton.getTop() + 12);
			bMapButton = true;

			if (mapActive) {
				tWard = wardList[SelectedTower].wardno;
				wardList[SelectedTower].bSelW = true;
				fName = baseLoc + "Ward_" + tWard + ".jpg";
				wardList[SelectedTower].draw();
				wardList[SelectedTower].drawmap(tWard, fName);
			} // if ...

			wardList[kW].draw();
		} // for ...

		ofSetColor(200, 200, 200);
		ofFill();
		ofDrawRectangle(ptYearButton, 65, 15);
		ofSetColor(0, 0, 0);
		ofDrawBitmapString("by Year", ptYearButton + ofVec2f(3, 12));		// byYear.getLeft() + 3, byYear.getTop() + 12);
		bYearButton = true;

		ofSetColor(200, 200, 200);
		ofFill();
		ofDrawRectangle(ptPriCrimeButton, 75, 15);
		ofSetColor(0, 0, 0);
		ofDrawBitmapString("by Crime", ptPriCrimeButton + ofVec2f(3, 12));
		bPriCrimeButton = true;
		break;
	case 1:							// Year
		ofSetColor(0, 0, 0);					// black
		ofDrawBitmapString(title3, ChiSealX - 350, 10);
		for (int kY = 0; kY < yearList.size(); kY++) {
			yearList[kY].draw();
			if (yearList[kY].bSelY) setYearBlock(kY);
		} // for ...
		break;
	case 2:							// Primary Crime
		ofSetColor(0, 0, 0);					// black
		ofDrawBitmapString(title6, ChiSealX - 430, 10);
		for (int kY = 0; kY < pricrimeList.size(); kY++) {	
			pricrimeList[kY].draw();
			if (pricrimeList[kY].bSelPC) setPriCrimeBlock(kY);
		} // for ...
		break;
	case 3:							// Ward-Crime
		ofSetColor(0, 0, 0);					// black
		ofDrawBitmapString(title5, ChiSealX - 450, 10);
		for (int kWC2 = 0; kWC2 < WCList2.size(); kWC2++) {
			WCList2[kWC2].draw();
			if (WCList2[kWC2].bSelWC) setWCBlock(kWC2);
		} // for ...
		break;
	case 4:							// Ward-Year
		ofSetColor(0, 0, 0);					// black
		ofDrawBitmapString(title4, ChiSealX - 400, 10);
		for (int kWY2 = 0; kWY2 < WYList2.size(); kWY2++) {
			WYList2[kWY2].draw();
			if (WYList2[kWY2].bSelWY) setWYBlock(kWY2);
		} // for ...
		break;
	default:
		break;
	}; // switch ...
} // draw ...

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
	ofImage scrnImg;

	switch (key) {
	case 'F':
	case 'f':
		ofToggleFullscreen();
		WinW = ofGetWindowWidth();
		WinH = ofGetWindowHeight();
		break;
	case 'S':
	case 's':
		scrnImg.grabScreen(0, 0, WinW, WinH);
		scrnImg.save("ScreenImage3.jpg", OF_IMAGE_QUALITY_HIGH);
		cout << "Image saved as \"ScreenImage3.jpg\"" << endl;
		break;
	default:
		break;
	} //switch ...
} 

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button) {
	string fName, tWard;

	if (button != 0) return;

	if (Yactive) {
		bool notInY = false;
		for (int k = 0; k < yearList.size(); k++) {
			notInY = notInY || yearList[k].inside(x, y);
		}
		if (!notInY) Yactive = false;
	}
	if (PCactive) {
		bool notInPC = false;
		for (int k = 0; k < pricrimeList.size(); k++) {
			notInPC = notInPC || pricrimeList[k].inside(x, y);
		}
		if (!notInPC) PCactive = false;
	}
	if (WYactive) {
		bool notInWY = false;
		if (WYList2.size() > 0) {
			for (int k = 0; k < WYList2.size(); k++) {
				notInWY = notInWY || WYList2[k].inside(x, y);
			}
		}
		if (!notInWY) WYactive = false;
	}
	if (WCactive) {
		bool notInWC = false;
		if (WCList2.size() > 0) {
			for (int k = 0; k < WCList2.size(); k++) {
				notInWC = notInWC || WCList2[k].inside(x, y);
			}
		}
		if (!notInWC) WCactive = false;
	}

	if ((!Yactive) && (!PCactive) && (!WYactive) && (!WCactive)) {
		if (bYearButton) {
			if (byYearButton.inside(x, y))
				Yactive = true;
			else Yactive = false;
		}

		if (bPriCrimeButton) {
			if (byPriCrimeButton.inside(x, y))
				PCactive = true;
			else PCactive = false;
		}

		if (SelectedTower != -1) {
			if (mapButton.inside(x, y)) {
				mapActive = true;
				bMapButton = true;
//			cout << "mapButton hit." << endl;
				tWard = wardList[SelectedTower].wardno;
				fName = baseLoc + "Ward_" + tWard + ".jpg";

				wardList[SelectedTower].draw();
				wardList[SelectedTower].drawmap(tWard, fName);
			}
			else {
				mapActive = false;
				bMapButton = false;
//				cout << "SelectedTower=" << SelectedTower << endl;
				wardList[SelectedTower].draw();
			}
		}
	} // if ...
} // mousePressed ...

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button) {

	if (button != 0) return;

	bMapButton = false;

	int mySW = 0;					// Ward active (default)
	if (Yactive) mySW = 1;			// Year active
	if (PCactive) mySW = 2;			// Primary Crime active
	if (WCactive) mySW = 3;			// Ward-Crime active
	if (WYactive) mySW = 4;			// Ward-Year active

	switch (mySW) {
	case 0:							// Ward
		bYearButton = true;			// Year button available
		bPriCrimeButton = true;		// Primary Crime button available

		for (int kW = 1; kW < wardList.size(); kW++) {
			if (wardList[kW].inside(x, y)) {
				if (SelectedTower != kW)
					for (int kW2 = 1; kW2 < wardList.size(); kW2++) {
						wardList[kW2].bSelW = false;		// reset prior select
					}
				wardList[kW].bSelW = true;					// set new select
				SelectedTower = kW;							// remember select
				bMapButton = true;	// map button available
			}
			else {
				bMapButton = false;
//				bYearButton = false;
//				bPriCrimeButton = false;
			}

			string wn = wardList[kW].wardno;
			if (wardList[kW].insid2(x, y)) {
				wardList[kW].bSelW = true;
				SelectedTower = kW;

				WYList2.clear();						// depopulate list
				sWYMax = 0;
				for (int kWY = 0; kWY < WYList1.size(); kWY++) {
					if (wn == WYList1[kWY].wardno) {	// match ward number
						if (WYList1[kWY].stats > sWYMax) sWYMax = WYList1[kWY].stats;
						WYList2.push_back(WYList1[kWY]);
					} // if ...
				} // for ...
				sWYMax = sWYMax * 1.05;
				for (int kWY = 0; kWY < WYList2.size(); kWY++) {
					WYList2[kWY].hi = (WYList2[kWY].stats / sWYMax) * tMaxSiz; // height
				}
				WYactive = true;						// ward by year activated
				WCactive = false;
			} // if insid2 ...
			else {
				if (wardList[kW].insid3(x, y)) {
					wardList[kW].bSelW = true;
					SelectedTower = kW;
					
					WCList2.clear();						// depopulate list
//					sWCMax = 0;
					for (int kWC = 0; kWC < WCList1.size(); kWC++) {
						if (wn == WCList1[kWC].wardno) {	// match ward number
//							if (WCList1[kWC].stats > sWCMax) sWCMax = WCList1[kWC].stats;
							WCList2.push_back(WCList1[kWC]);
//							cout << "WC-" << WCList2.size() << endl;
						}
					}
//					sWCMax = sWCMax * 1.05;
					for (int kWC = 0; kWC < WCList2.size(); kWC++) {
						WCList2[kWC].hi = int((log10f(WCList2[kWC].stats) / log10f(sWCMax)) * tMaxSiz); // height
					}
					WCactive = true;			// ward by crime activated
					WYactive = false;
				} // if insid3 ...
			} // else ...
		} // for int kW ...
		if (SelectedTower != -1) wardList[SelectedTower].draw();
		break;
	case 1:							// Year
		for (int kY = 0; kY < yearList.size(); kY++) {
			yearList[kY].bSelY = false;
			if (yearList[kY].inside(x, y)) {
				yearList[kY].bSelY = true;
			}
//			else Yactive = false;				// kills year panel
		} // for 
		break;
	case 2:							// Primary Crime
		for (int kPC = 0; kPC < pricrimeList.size(); kPC++) {
			pricrimeList[kPC].bSelPC = false;
			if (pricrimeList[kPC].inside(x, y)) {
				pricrimeList[kPC].bSelPC = true;
			}
//			else PCactive = false;				// kills primary crime panel
		} // for 
		break;
	case 3:							// Ward-Crime
		for (int kWC = 0; kWC <WCList2.size(); kWC++) {
			WCList2[kWC].bSelWC = false;
			if (WCList2[kWC].inside(x, y)) {
				WCList2[kWC].bSelWC = true;
			}
//			else WCactive = false;				// kills ward-crime panel
		} // for 
		break;
	case 4:							// Ward-Year
		for (int kWY = 0; kWY <WYList2.size(); kWY++) {
			WYList2[kWY].bSelWY = false;
			if (WYList2[kWY].inside(x, y)) {
				WYList2[kWY].bSelWY = true;
			}
//			else WYactive = false;				// kills ward-year panel
		} // for 
		break;
	default:
		break;
	}; // switch ...

} // mouseReleased ...

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){
	WinW = ofGetWindowWidth();					// Window dimensions
	WinH = ofGetWindowHeight();

	ofPoint ptYearButton = ofPoint(WinW - (ChiSeal.getWidth() + osYearButton), 23);
	byYearButton.set(ptYearButton, 60, 15);
//	bYearButton = true;

	ofPoint ptPriCrimeButton = ofPoint(WinW - (ChiSeal.getWidth() + osPriCrimeButton), 43);
	byPriCrimeButton.set(ptPriCrimeButton, 70, 15);
//	bPriCrimeButton = true;

	mapButton.set(ptMapButton, 45, 15);
//	bMapButton = false;

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}

//--------------------------------------------------------------
void ofApp::renderSelection() {

}

//--------------------------------------------------------------
void ofApp::processSelection(int x, int y) {

}

//--------------------------------------------------------------
long ofApp::getWardDataMax(string fName) {
	//	cout << "getWardData." << endl;
	int k;
	long gWardMax = 0;

	ifstream myF1(fName);
	if (!myF1.is_open()) {
		cout << "unable to open file [" << fName << "]" << endl;
		return 0;
	}
	else {
		while (getline(myF1, tLine)) {
			size_t found = tLine.find(",");
			lineWardNumber = tLine.substr(0, found);
			lineWardValue = stoll(tLine.substr(found + 1, 10));

			k = stoi(lineWardNumber);
			if (k != 0)
				if (lineWardValue > gWardMax) 			// find largest value
					gWardMax = lineWardValue;
		}
		myF1.close();
	}

	gWardMax = gWardMax * 1.05;							// inflate max by 15%
	return gWardMax;
}

//--------------------------------------------------------------
bool ofApp::getWardData(string fName) {
	int k;

	ifstream myF2(fName);								// process Wards.txt
	if (!myF2.is_open()) {
		cout << "unable to open file [" << fName << "]" << endl;
		return false;
	}
	else {
		while (getline(myF2, tLine)) {
			size_t found = tLine.find(",");
			lineWardNumber = tLine.substr(0, found);
			lineWardValue = stoll(tLine.substr(found + 1, 10));

			k = stoi(lineWardNumber);
			if (k == 0) {
				myWardTower.wardno = k;					// Ward Number
				myWardTower.AldNm = "";		// tAlderman;			// Alderman Name (future)
				myWardTower.stats = 0;					// Statistic
			}
			else {
				myWardTower.wardno = lineWardNumber;	// Ward Number
				myWardTower.AldNm = "";		// tAlderman;			// Alderman Name (future)
				myWardTower.stats = lineWardValue;		// Statistic
			}

			myWardTower.rot = 0;						// rotation
			myWardTower.trans.x = (k + 1) * shiftX;		// x
			myWardTower.hi = (myWardTower.stats / sWardMax) * tMaxSiz;		// height
			myWardTower.trans.y = WinH - 35;			// y
			myWardTower.trans.z = 0;					// z
//			myWardTower.built = true;

			myWardTower.bSelW = false;
			wardList.push_back(myWardTower);			// tower definition into array
		}
		myF2.close();
		return true;
	}
}

//--------------------------------------------------------------
void ofApp::setWardBlock(int k) {
	int xLeft, xWide, x3, yTop, yHigh;

	if (wardList[k].trans.x < 200) xLeft = 210;
	else xLeft = 40;
	xWide = 200;
	x3 = xLeft + 5;
	yTop = 10;
	yHigh = 70;

	ofSetColor(0, 0, 0);					// white				
	ofFill();
	ofDrawRectangle(xLeft - 1, yTop - 1, xWide + 2, yHigh + 2);
	ofSetColor(255, 255, 0);				// yellow
	ofRectangle wardInfoRect(xLeft, yTop, xWide, yHigh);
	ofDrawRectangle(wardInfoRect);

	ofSetColor(255, 0, 0);					// red
	ofDrawBitmapString("Ward: " + wardList[k].wardno, x3, yTop + 20);
	ofDrawBitmapString("Stats: " + makeComma(int(wardList[k].stats)), x3, yTop + 40);
	ofDrawBitmapString("Alderman: " + wardList[k].AldNm, x3, yTop + 60);
}

//--------------------------------------------------------------
long ofApp::getYearDataMax(string fName) {
//	cout << "getYearDataMax. fName=" << fName << endl;
	long myYearMax = 0;

	ifstream myF1y(fName);
	if (!myF1y.is_open()) {
		cout << "unable to open file [" << fName << "]" << endl;
		return 0;
	}
	else {
		while (!myF1y.eof()) {
			getline(myF1y, tLine);
			if (tLine != "") {
				// line format is "year,statistic"
				// find Year Number
				size_t pos = tLine.find(Cdelim);
				lineYearNumber = tLine.substr(0, pos);
				tLine.erase(0, pos + Cdelim.length());
				// find Year Statistic
				lineYearValue = stoll(tLine.substr(0, tLine.length()));
				//			if (lineYearNumber != "0")				// ignore zero/blank year (if any)
				if (lineYearValue > myYearMax)			// find largest value
					myYearMax = lineYearValue;
				//			cout << " [3]";
			}
		} // while ...

//		cout << "File myF1y close." << endl;
		myF1y.close();
	} // else ...

	myYearMax = myYearMax * 1.05;					// inflate max by 5%
	return myYearMax;
}

//--------------------------------------------------------------
bool ofApp::getYearData(string fName) {
//	cout << "getYearData. fName=" << fName << endl;
	long k;
	
	ifstream myF2y(fName);								// process Wards.txt
	if (!myF2y.is_open()) {
		cout << "unable to open file [" << fName << "]" << endl;
		return false;
	}
	else {
		while (!myF2y.eof()) {
			getline(myF2y, tLine);
			if (tLine != "") {
				// line format is "year,statistic"
				// find Year Number
				size_t pos = tLine.find(Cdelim);
				lineYearNumber = tLine.substr(0, pos);
				tLine.erase(0, pos + Cdelim.length());
				// find Year Statistic
				lineYearValue = stoll(tLine.substr(0, tLine.length()));

//				cout << "Year=" << lineYearNumber << endl;
				myYearTower.theYear = lineYearNumber;		// Year Number
				if ((lineYearNumber != "0") && (lineYearNumber != "")) // ignore zero year (if any)
					myYearTower.stats = lineYearValue;	// Statistic
				else myYearTower.stats = 0;					// Statistic

				myYearTower.rot = 0;						// rotation
				k = stoi(lineYearNumber) - tBaseYear;
				myYearTower.trans.x = (k + 2) * shiftX;		// x
				myYearTower.hi = (myYearTower.stats / sYearMax) * tMaxSiz;	// height
				myYearTower.trans.y = WinH - tBaseOffset;	// y
				myYearTower.trans.z = 0;					// z
				myYearTower.built = true;

				myYearTower.bSelY = false;
				yearList.push_back(myYearTower);			// tower definition into array
			} // if ...
		} // while ...
	} // else ...

	myF2y.close();
	return true;
}

//--------------------------------------------------------------
void ofApp::setYearBlock(int k) {
	int xLeft, xWide, x3, yTop, yHigh;

	if (yearList[k].trans.x < 240) xLeft = 250;
	else xLeft = 40;
	xWide = 200;
	x3 = xLeft + 5;
	yTop = 10;
	yHigh = 50;

	ofSetColor(0, 0, 0);					// white				
	ofFill();
	ofDrawRectangle(xLeft - 1, yTop - 1, xWide + 2, yHigh + 2);
	ofSetColor(255, 255, 0);				// yellow
	ofRectangle yearInfoRect(xLeft, yTop, xWide, yHigh);
	ofDrawRectangle(yearInfoRect);

	ofSetColor(255, 0, 0);					// red
	ofDrawBitmapString("Year: " + yearList[k].theYear, x3, yTop + 20);
	ofDrawBitmapString("Stats: " + makeComma(int(yearList[k].stats)), x3, yTop + 40);
}

//--------------------------------------------------------------
long ofApp::getPriCrimeDataMax(string fName) {
//	cout << "getPriCrimeDataMax. fName=" << fName << endl;
//	long myPriCrimeMax = 0;

	ifstream myF1pc(fName);
	if (!myF1pc.is_open()) {
		cout << "unable to open file [" << fName << "]" << endl;
		return 0;
	}
	else {
		while (!myF1pc.eof()) {
			getline(myF1pc, tLine);
			if (tLine != "") {
				// line format is "crime,statistic"
				// find Primary Crime
				size_t pos = tLine.find(Cdelim);
				linePriCrime = tLine.substr(0, pos);
				tLine.erase(0, pos + Cdelim.length());
				// find PriCrime Statistic
				linePriCrimeValue = stoll(tLine.substr(0, tLine.length()));
				//			if (lineYearNumber != "0")		// ignore zero/blank year (if any)
				if (linePriCrimeValue > sPriCrimeMax)		// find largest value
					sPriCrimeMax = linePriCrimeValue;
				//			cout << " [3]";
			}
		} // while ...

//		cout << "File myF1pc close." << endl;
		myF1pc.close();
	} // else ...

	sPriCrimeMax = sPriCrimeMax * 1.05;					// inflate max by 5%
	return sPriCrimeMax;
}

//--------------------------------------------------------------
bool ofApp::getPriCrimeData(string fName) {
//	cout << "getPriCrimeData. fName=" << fName << endl;
	long k;

	ifstream myF2pc(fName);								// process Wards.txt
	if (!myF2pc.is_open()) {
		cout << "unable to open file [" << fName << "]" << endl;
		return false;
	}
	else {
		k = 0;
		while (!myF2pc.eof()) {
			getline(myF2pc, tLine);
			if (tLine != "") {
				// line format is "PriCrime,statistic"
				// find Primary Crime
				size_t pos = tLine.find(Cdelim);
				linePriCrime = tLine.substr(0, pos);
				tLine.erase(0, pos + Cdelim.length());
				// find PriCrime Statistic
				linePriCrimeValue = stoll(tLine.substr(0, tLine.length()));

				myPriCrimeTower.theCrime = linePriCrime;
				myPriCrimeTower.code = k;
				myPriCrimeTower.stats = linePriCrimeValue;		// Statistic
//				cout << "Crime=" << myPriCrimeTower.stats << endl;

				myPriCrimeTower.rot = 0;						// rotation
				myPriCrimeTower.trans.x = (k + 2) * shiftX;		// x
//				myPriCrimeTower.hi = (myPriCrimeTower.stats / sPriCrimeMax) * tMaxSiz;	// height
				myPriCrimeTower.hi = (log10f(myPriCrimeTower.stats) / log10f(sPriCrimeMax)) * tMaxSiz;	// height
				myPriCrimeTower.trans.y = WinH - tBaseOffset;	// y
				myPriCrimeTower.trans.z = 0;					// z
				myPriCrimeTower.built = true;

				myPriCrimeTower.bSelPC = false;
				pricrimeList.push_back(myPriCrimeTower);		// tower definition into array
				k = k++;
			} // if ...
		} // while ...
	} // else ...

	myF2pc.close();
	return true;
}

//--------------------------------------------------------------
void ofApp::setPriCrimeBlock(int k) {
	int xLeft, xWide, x3, yTop, yHigh;

	if (pricrimeList[k].trans.x < 240) xLeft = 250;
	else xLeft = 40;
	xWide = 300;
	x3 = xLeft + 5;
	yTop = 10;
	yHigh = 50;

	ofSetColor(0, 0, 0);					// white				
	ofFill();
	ofDrawRectangle(xLeft - 1, yTop - 1, xWide + 2, yHigh + 2);
	ofSetColor(255, 255, 0);				// yellow
	ofRectangle pricrimeInfoRect(xLeft, yTop, xWide, yHigh);
	ofDrawRectangle(pricrimeInfoRect);

	ofSetColor(255, 0, 0);					// red
	ofDrawBitmapString("Crime: " + to_string(pricrimeList[k].code) +
		" -- " + pricrimeList[k].theCrime, x3, yTop + 20);
	ofDrawBitmapString("Stats: " + makeComma(int(pricrimeList[k].stats)), x3, yTop + 40);
}

//--------------------------------------------------------------
string ofApp::makeComma(int stats) {
	string mm = to_string(stats);
	int iP = mm.length() - 3;
	//			cout << "[" << mm << "], iP=" << iP << endl;
	while ((iP > 0) && (iP <= mm.length())) {
		mm.insert(iP, ",");
		iP = iP -= 3;
	}
	return mm;
}

//--------------------------------------------------------------
long ofApp::getWYDataMax(string fName) {
	//	cout << "getWYData." << endl;
	long gWYMax = 0;

	ifstream myF1(fName);
	if (!myF1.is_open()) {
		cout << "unable to open file [" << fName << "]" << endl;
		return 0;
	}
	else {
		while (getline(myF1, tLine)) {
			size_t pos = 0;
			pos = tLine.find(Cdelim);
			lineWYNumber = tLine.substr(0, pos);		// wardno
			tLine.erase(0, pos + Cdelim.length());
			pos = tLine.find(Cdelim);
			// skip the year
			tLine.erase(0, pos + Cdelim.length());
			lineWYValue = stod(tLine);

			if (lineWYNumber != "0")
				if (lineWYValue > gWYMax)	// find largest value
					gWYMax = lineWYValue;
		}
		myF1.close();
	}

	gWYMax = gWYMax * 1.05;								// inflate max by 15%
	return gWYMax;
}

//--------------------------------------------------------------
bool ofApp::getWYData(string fName) {
	long k = 0, k2, yy;

	ifstream myF2(fName);								// process Wards.txt
	if (!myF2.is_open()) {
		cout << "unable to open file [" << fName << "]" << endl;
		return false;
	}
	else {
		while (getline(myF2, tLine)) {
			size_t pos = 0;
			pos = tLine.find(Cdelim);
			lineWYNumber = tLine.substr(0, pos);		// wardno
			tLine.erase(0, pos + Cdelim.length());
			pos = tLine.find(Cdelim);
			lineWYYear = tLine.substr(0, pos);			// year
			tLine.erase(0, pos + Cdelim.length());
			lineWYValue = stod(tLine);					// value

			if (lineWYNumber != "0") 	
				myWYTower.stats = lineWYValue;			// Statistic
			else myWYTower.stats = 0;					// Statistic

			myWYTower.wardno = lineWYNumber;
			myWYTower.theYear = lineWYYear;				// Year Number

			myWYTower.rot = 0;							// rotation

			k2 = stoi(lineYearNumber);
			if (k2 != k) k = stoi(lineYearNumber);
			yy = stoi(lineWYYear) - 2001;
			myWYTower.trans.x = (yy + 2) * shiftX;		// x
			myWYTower.hi = (myWYTower.stats / sWYMax) * tMaxSiz; // height
			myWYTower.trans.y = WinH - 35;				// y
			myWYTower.trans.z = 0;						// z
			myWYTower.built = true;

			myWYTower.bSelWY = false;
			WYList1.push_back(myWYTower);				// tower definition into array
		}
		myF2.close();
		return true;
	}
}

//--------------------------------------------------------------
void ofApp::setWYBlock(int k) {
	int xLeft, xWide, x3, yTop, yHigh;

	if (WYList2[k].trans.x < 350) xLeft = 375;
	else xLeft = 40;
	xWide = 200;
	x3 = xLeft + 5;
	yTop = 10;
	yHigh = 50;

	ofSetColor(0, 0, 0);					// white				
	ofFill();
	ofDrawRectangle(xLeft - 1, yTop - 1, xWide + 2, yHigh + 2);
	ofSetColor(255, 255, 0);				// yellow
	ofRectangle WYInfoRect(xLeft, yTop, xWide, yHigh);
	ofDrawRectangle(WYInfoRect);

	ofSetColor(255, 0, 0);					// red
	ofDrawBitmapString("Ward: " + WYList2[k].wardno, x3, yTop + 12);
	ofDrawBitmapString("Year: " + WYList2[k].theYear, x3, yTop + 28);
	ofDrawBitmapString("Stats: " + makeComma(int(WYList2[k].stats)), x3, yTop + 44);
}

//--------------------------------------------------------------
long ofApp::getWCDataMax(string fName) {
//	cout << "getWCData." << endl;
	long k = 0;
	string yylast = "";
	long gWCMax = 0;
	
	ifstream myF1(fName);
	if (!myF1.is_open()) {
		cout << "unable to open file [" << fName << "]" << endl;
		return false;
	}
	else {
		while (getline(myF1, tLine)) {
			size_t pos = 0;
			pos = tLine.find(Cdelim);
			lineWCNumber = tLine.substr(0, pos);		// wardno
			tLine.erase(0, pos + Cdelim.length());
			pos = tLine.find(Cdelim);
			// skip the crime
			tLine.erase(0, pos + Cdelim.length());
			lineWCValue = stod(tLine);

			if (lineWCNumber != "0")
				if (lineWCValue > gWCMax)	// find largest value
					gWCMax = lineWCValue;
		}
		myF1.close();
	}

	gWCMax = gWCMax * 1.05;					// inflate max by 15%
	return gWCMax;
}

//--------------------------------------------------------------
bool ofApp::getWCData(string fName) {
	long k = 0, k2, yy;
	
	ifstream myF2(fName);									// process Wards.txt
	if (!myF2.is_open()) {
		cout << "unable to open file [" << fName << "]" << endl;
		return false;
	}
	else {
		yy = 0;
		while (getline(myF2, tLine)) {
			size_t pos = 0;
			pos = tLine.find(Cdelim);
			lineWCNumber = tLine.substr(0, pos);	// wardno
			tLine.erase(0, pos + Cdelim.length());
			pos = tLine.find(Cdelim);
			lineWCCrime = tLine.substr(0, pos);		// the crime
			tLine.erase(0, pos + Cdelim.length());
			lineWCValue = stod(tLine);				// value

			if (lineWCNumber != "0")
				myWCTower.stats = lineWCValue;		// Statistic
			else myWCTower.stats = 0;				// Statistic

			myWCTower.wardno = lineWCNumber;
//			cout << "Year=" << lineYearNumber << ", Stat=" << lineYearValue << endl;
			myWCTower.theCrime = lineWCCrime;		// the Crime

			myWCTower.rot = 0;						// rotation

			k2 = stoi(lineWCNumber);
			if (k2 != k) {
				k = stoi(lineWCNumber);
				yy = 0;
			}
			myWCTower.trans.x = (yy + 2) * shiftX;	// x
			yy = yy++;	
			myWCTower.code = yy;
			myWCTower.hi = 0;		// (log10f(myWCTower.stats) / log10f(sWCMax)) * tMaxSiz; // height
			myWCTower.trans.y = WinH - 35;			// y
			myWCTower.trans.z = 0;					// z
			myWCTower.built = true;

			myWCTower.bSelWC = false;
			WCList1.push_back(myWCTower);		// tower definition into array
		}
		myF2.close();
		return true;
	}
}

//--------------------------------------------------------------
void ofApp::setWCBlock(int k) {
	int xLeft, xWide, x3, yTop, yHigh;

	if (WCList2[k].trans.x < 350) xLeft = 375;
	else xLeft = 40;
	xWide = 300;
	x3 = xLeft + 5;
	yTop = 10;
	yHigh = 50;

	ofSetColor(0, 0, 0);					// white				
	ofFill();
	ofDrawRectangle(xLeft - 1, yTop - 1, xWide + 2, yHigh + 2);
	ofSetColor(255, 255, 0);				// yellow
	ofRectangle WCInfoRect(xLeft, yTop, xWide, yHigh);
	ofDrawRectangle(WCInfoRect);

	ofSetColor(255, 0, 0);					// red
	ofDrawBitmapString("Ward: " + WCList2[k].wardno, x3, yTop + 12);
	ofDrawBitmapString("Crime: " +				// to_string(WCList2[k].code) + " -- " + 
		WCList2[k].theCrime, x3, yTop + 28);
	ofDrawBitmapString("Stats: " + makeComma(int(WCList2[k].stats)), x3, yTop + 44);
}
