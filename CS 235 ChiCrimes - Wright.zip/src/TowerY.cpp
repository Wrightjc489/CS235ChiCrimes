//	-------------------------------------------------------------
//	Copyright �2018, J.C.Wright, San Jose, CA"
//
//	CS 235, Spring 2018, San Jos� State University,
//								    	San Jose, CA
//
//	James C. Wright
//	Chicago Crime Statistics Visualization Project.
//	Credit to K. Smith for the code model.
//	-------------------------------------------------------------

#include "TowerY.h"
#include "ofApp.h"


//--------------------------------------------------------------
TowerYear::TowerYear()
{
	trans = ofVec3f(0, 0, 0);				// translation
	scale = ofVec3f(1, 1, 1);				// scale
	rot = 0;								// rotation (degrees)
	bSelY = false;							// not selected
}

//--------------------------------------------------------------
void TowerYear::draw() {
	ofVec3f abc;

	//	cout << "TowerYear::draw" << endl;
	ofPushMatrix();

//		if (theYear == "0") return;

		ofTranslate(trans);
		ofRotate(rot);
		ofScale(scale);

		abc = ofVec3f(0, -hi, 1.0);

		if (!bSelY) ofSetColor(150, 150, 150);		// grey
		else ofSetColor(255, 0, 255);				// fushia

		ofFill();
		ofDrawRectangle(abc,tWide2, hi);

		string myYear = theYear;
		string myStat = to_string(int(stats / 1000)) + "k";

		ofSetColor(0, 0, 0);						// black
		ofPoint pB = ofPoint(0, -hi - 3.0, 0.0);
		ofDrawBitmapString(myStat, pB);

		ofSetColor(255, 0, 0);						// red
		ofPoint pA = ofPoint(0.0, 12.0, 0.0);
		ofDrawBitmapString(myYear, pA);

	ofPopMatrix();
}

//--------------------------------------------------------------
bool TowerYear::inside(float x, float y) {		// return true(inside), false(not)
	int xLeft, xRight, yTop, yBot;

	bSelY = false;
	xLeft = trans.x;
	xRight = xLeft + tWide2;		// tWide;
	yTop = trans.y;
	yBot = trans.y - hi;
	if (((x >= xLeft) && (x <= xRight)) && ((y <= yTop) && (y >= yBot)))
		return true;
	else
		return false;
}

